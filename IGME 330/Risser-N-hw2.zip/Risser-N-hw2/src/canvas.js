/*
	The purpose of this file is to take in the analyser node and a <canvas> element: 
	  - the module will create a drawing context that points at the <canvas> 
	  - it will store the reference to the analyser node
	  - in draw(), it will loop through the data in the analyser node
	  - and then draw something representative on the canvas
	  - maybe a better name for this file/module would be *visualizer.js* ?
*/

import * as utils from './utils.js';

let ctx,canvasWidth,canvasHeight,gradient,analyserNode,audioData;
let botWidth = 120;
let avgHeight = 0;

const getRandomColor= () =>
	{
		function getByte(){
			return 55 + Math.round(Math.random() * 200);
		}
		return "rgba(" + getByte() + "," + getByte() + "," + getByte() + ",.8)";
	}


const setupCanvas = (canvasElement,analyserNodeRef) => {
	// create drawing context
	ctx = canvasElement.getContext("2d");
	canvasWidth = canvasElement.width;
	canvasHeight = canvasElement.height;
	// create a gradient that runs top to bottom
	gradient = utils.getLinearGradient(ctx,0,0,0,canvasHeight,[{percent:0,color:"#DAFFFB"},{percent:.25,color:"#176B87"},{percent:.5,color:"#04364A"},{percent:.75,color:"#176B87"},{percent:1,color:"#DAFFFB"}]);
	// keep a reference to the analyser node
	analyserNode = analyserNodeRef;
	// this is the array where the analyser data will be stored
	audioData = new Uint8Array(analyserNode.fftSize/2);
}

const drawRect = (ctx,x,y,width,height,fillStyle="black",lineWidth=0,strokeStyle="black") =>
	{
		ctx.save();
		ctx.beginPath();
		ctx.lineWidth = lineWidth;
		ctx.strokeStyle = strokeStyle;
		ctx.fillStyle = fillStyle;
		ctx.rect(x, y, width, height);
		ctx.closePath();
		ctx.fill();
		ctx.stroke();
		ctx.restore();
	}

const draw = (params={}) =>{


    // Draw head
    drawRect(ctx, 375, 170, 50, 25, "#363062", 0, "#363062");    // Neck
    drawRect(ctx, 360, 150, 80, 20, "#F99417", 0, "#F99417");      // Bottom Jaw
    drawRect(ctx, 350, 100 - avgHeight * 1.5, 100, 50, "#4D4C7D", 4, "#4D4C7D");      // Top Head

    // Arms
    drawRect(ctx, 330, 215, 10, 20, "#363062", 0, "#363062");    // Left Connect 
    drawRect(ctx, 324, 200, 4, 120, "#F99417", 0, "#F99417");       // Left Arm
    drawRect(ctx, 460, 215, 10, 20, "#363062", 0, "#363062");    // Right Connect 
    drawRect(ctx, 470, 200, 4, 120, "#F99417", 0, "#F99417");       // Right Arm

    // Legs 
    drawRect(ctx, 360, 335, 10, 50, "#363062", 4, "#363062");    // Left Leg  
    drawRect(ctx, 350, 385, 20, 10, "#4D4C7D", 4, "#4D4C7D");    // Left Foot  
    drawRect(ctx, 430, 335, 10, 50, "#363062", 4, "#363062");    // Right Leg  
    drawRect(ctx, 430, 385, 20, 10, "#4D4C7D", 4, "#4D4C7D");    // Right FOot   
    
    // Main Body
    drawRect(ctx, 340, 195, botWidth, 140, "#4D4C7D", 0, "#4D4C7D");     // Body Frame
    drawRect(ctx, 350, 210, 100, 20, "#F5F5F5", 0, "black");  // Song Display 
    drawRect(ctx, 350, 260, 100, 50, "#F5F5F5", 0, "#black");  // Wire Display 

   


  // 1 - populate the audioData array with the frequency data from the analyserNode
	// notice these arrays are passed "by reference" 
	analyserNode.getByteFrequencyData(audioData);
	// OR
	//analyserNode.getByteTimeDomainData(audioData); // waveform data
	
	// 2 - draw background
	ctx.save();
    ctx.fillStyle = "black";
	ctx.globalAlpha = 0.1;
    ctx.fillRect(0,0,canvasWidth, canvasHeight);
    ctx.restore();
	// 3 - draw gradient
	if(params.showGradient)
    {
        ctx.save();
        ctx.fillStyle = gradient;
        ctx.globalAlpha = 0.3;
        ctx.fillRect(0,0,canvasWidth,canvasHeight);
        ctx.restore();
    }
	// 4 - draw bars
    if(params.talk)
    {
        let barSpacing = 0;
        let margin = 360;
        //let screenWidthForBars = botWidth  - (audioData.length * barSpacing) - margin * 2;
        let barWidth = 80 / audioData.length;
        let barHeight = 30;
        let topSpacing = 150;

        let heightMul = 0.2;
        let sum = 0;
        
        ctx.save();
        ctx.fillStyle = 'rgba(255,255,255,0.50)';
        ctx.strokeStyle = 'rgba(0,0,0,0.50)';

        // Loop through data to draw  
        for(let i = 0; i < audioData.length; i++)
        {
            let difference =audioData[i] * heightMul;

            if(i > 20)
            {
                sum += difference;
            }
            //ctx.fillRect(margin + i * (barWidth + barSpacing), topSpacing - difference, barWidth, barHeight); // 256 - audiodat.. for y
            //ctx.strokeRect(margin + i * (barWidth + barSpacing), topSpacing - difference, barWidth, barHeight);
        }

        avgHeight = sum / audioData.length;
        ctx.restore();
    }
    else
    {
        avgHeight = 0;
    }
	
	// 5 - draw circles
	if (params.showLine)
    {
        ctx.save();
        ctx.strokeStyle = "#black";
        ctx.lineWidth = 3;

        let startX = 355;
        let width = 90;

        let x = 0;
        let middleY = 295;
        let y = middleY;

        ctx.beginPath();
        ctx.moveTo(startX, y);
        for(let b of audioData)
        {
            ctx.lineTo(startX + x, (y- Math.min(b * 0.1, 30)));
            x += (width/audioData.length);
        }
        ctx.stroke();
        ctx.closePath();
        ctx.restore();


        // let maxRadius = canvasHeight / 4;
        // ctx.save();
        // ctx.globalAlpha = 0.5;

        // for(let i = 0; i < audioData.length; i++)
        // {
        //     let percent = audioData[i] / 255;

        //     // Blueish circles 
        //     let circleRadius = percent * maxRadius;
        //     ctx.beginPath();
        //     ctx.fillStyle = utils.makeColor(255, 111, 111, 0.34 - percent / 3.0);
        //     ctx.arc(canvasWidth / 2, canvasHeight / 2, circleRadius, 0, 2 * Math.PI, false);
        //     ctx.fill();
        //     ctx.closePath();

        //     // Yellowish circles 
        //     ctx.save();
        //     ctx.beginPath();
        //     ctx.fillStyle = utils.makeColor(200, 200, 0, 0.5 - percent / 5.0);
        //     ctx.arc(canvasWidth / 2, canvasHeight / 2, circleRadius * 0.50, 0, 2 * Math.PI, false);
        //     ctx.fill();
        //     ctx.closePath();
        //     ctx.restore();
        // }
        // ctx.restore();
    }

    // 6 - bitmap manipulation
	// TODO: right now. we are looping though every pixel of the canvas (320,000 of them!), 
	// regardless of whether or not we are applying a pixel effect
	// At some point, refactor this code so that we are looping though the image data only if
	// it is necessary

	// A) grab all of the pixels on the canvas and put them in the `data` array
	// `imageData.data` is a `Uint8ClampedArray()` typed array that has 1.28 million elements!
	// the variable `data` below is a reference to that array 
	let imageData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
    let data = imageData.data;
    let length = data.length;
    let width = imageData.width;

	// B) Iterate through each pixel, stepping 4 elements at a time (which is the RGBA for 1 pixel)
    for(let i = 0; i < length; i += 4)
    {
        // C) randomly change every 20th pixel to red

        if(params.showNoise && Math.random() < 0.05)
        {
            // data[i] is the red channel
            // data[i+1] is the green channel
            // data[i+2] is the blue channel
            // data[i+3] is the alpha channel

            data[i] = data[i+1] = data[i+2] = 255; // zero out the red and green and blue channels
            //data[i] = 255;  // make the red channel 100% red
        }

        if(params.showInvert)
        {
            let red = data[i], green = data[i + 1], blue = data[i + 2];
            data[i] = 255 - red;
            data[i + 1] = 255 - green;
            data[i + 2] = 255 - blue;
            // data[i + 3] is the alpha 
        }
    }

    if(params.showEmboss)
    {
        for(let i = 0; i < length; i++)
        {
            if (i % 4 == 3) continue; // skill alpha 
            data[i] = 127 + 2 * data[i] - data[i + 4] - data[i + width * 4];
        }
    }
    
		
	// D) copy image data back to canvas
    ctx.putImageData(imageData, 0, 0);

    
}

export {setupCanvas,draw};