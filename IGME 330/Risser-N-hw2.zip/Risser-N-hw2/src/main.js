/*
	main.js is primarily responsible for hooking up the UI to the rest of the application 
	and setting up the main event loop
*/

// We will write the functions in this file in the traditional ES5 way
// In this instance, we feel the code is more readable if written this way
// If you want to re-write these as ES6 arrow functions, to be consistent with the other files, go ahead!

import * as utils from './utils.js';
import * as audio from './audio.js';
import * as canvas from './canvas.js';

const drawParams =
{
  showGradient  : false,
  talk          : true,
  showLine      : true,
  showNoise     : false,
  showInvert    : false,
  showEmboss    : false
};

// 1 - here we are faking an enumeration
const DEFAULTS = Object.freeze({
	sound1  :  "media/ULTRAKILL.mp3"
});

const loop = () => {
  /* NOTE: This is temporary testing code that we will delete in Part II */
    //requestAnimationFrame(loop);

    setTimeout(loop, 1000 / 60);
    canvas.draw(drawParams);

  // Old debug information below 

    // 1) create a byte array (values of 0-255) to hold the audio data
    // normally, we do this once when the program starts up, NOT every frame
   // let audioData = new Uint8Array(audio.analyserNode.fftSize/2);
    
    // 2) populate the array of audio data *by reference* (i.e. by its address)
    //audio.analyserNode.getByteFrequencyData(audioData);
    
    // 3) log out the array and the average loudness (amplitude) of all of the frequency bins
      // console.log(audioData);
      
      // console.log("-----Audio Stats-----");
      // let totalLoudness =  audioData.reduce((total,num) => total + num);
      // let averageLoudness =  totalLoudness/(audio.analyserNode.fftSize/2);
      // let minLoudness =  Math.min(...audioData); // ooh - the ES6 spread operator is handy!
      // let maxLoudness =  Math.max(...audioData); // ditto!
      // // Now look at loudness in a specific bin
      // // 22050 kHz divided by 128 bins = 172.23 kHz per bin
      // // the 12th element in array represents loudness at 2.067 kHz
      // let loudnessAt2K = audioData[11]; 
      // console.log(`averageLoudness = ${averageLoudness}`);
      // console.log(`minLoudness = ${minLoudness}`);
      // console.log(`maxLoudness = ${maxLoudness}`);
      // console.log(`loudnessAt2K = ${loudnessAt2K}`);
      // console.log("---------------------");
  }


  const loadJson = () =>
{
    const url = "data/av-data.json";
    const xhr = new XMLHttpRequest();
    xhr.onload = (e) =>
    {
        console.log(`In onload - HTTP Status Code = ${e.target.status}`);
        const text = e.target.responseText;
        let json = JSON.parse(text);
        
        let title = json["title"];
        let songTitle = json["songTitles"];
        let instruct = json["funky"];

        document.querySelector("#title").innerHTML = title;
        document.querySelector("#desc").innerHTML = instruct;
    }

    xhr.onerror = e => console.log(`In onerror - HTTP Status Code = ${e.target.status}`);
    xhr.open("GET", url);
    xhr.send();
}

const setupUI = (canvasElement) => {
  // A - hookup fullscreen button
  const fsButton = document.querySelector("#fs-button");
  
  // add .onclick event to button
  fsButton.onclick = e => {
    console.log("goFullscreen() called");
    utils.goFullscreen(canvasElement);
  };


  playButton.onclick = e => 
  {
    console.log(`audioCtx.state before = ${audio.audioCtx.state}`);

    if(audio.audioCtx.state == "suspended")
    {
      audio.audioCtx.resume();
    }

    if(audio.audioCtx.state == "running")
    {
      audio.audioCtx.suspend();
      playButton.content = "no";
    }

    if(e.target.dataset.playing == "no")
    {
      audio.playCurrentSound();
      e.target.dataset.playButton = "yes";
    }
    else
    {
      audio.pauseCurrentSound();
      e.target.dataset.playButton = "no";
    }
  }

  // Hookup track
  let trackSelect = document.querySelector("#track-select");
  trackSelect.onchange = e =>
  {
    audio.loadSoundFile(e.target.value);
    if(playButton.dataset.playing == "yes")
    {
      playButton.dispatchEvent(new MouseEvent("click"));
    }
  }


  // Set up checkboxes 
  const btnGradient = document.querySelector("#cb-gradient");
  btnGradient.checked = true;
  btnGradient.onclick = () => {
    drawParams.showGradient = btnGradient.checked;
  };

  const btnBars = document.querySelector("#cb-talk");
  btnBars.checked = true;
  btnBars.onclick = () => {
    drawParams.talk = btnBars.checked;
  };
  
  const btnLine = document.querySelector("#cb-line"); 
  btnLine.checked = true;
  btnLine.onclick = () => {
    drawParams.showLine = btnLine.checked;
  };

  const btnNoise = document.querySelector("#cb-noise");
  btnNoise.checked = false;
  btnNoise.onclick = () => {
    drawParams.showNoise = btnNoise.checked;
  };

  const btnInvert = document.querySelector("#cb-invert");
  btnInvert.checked = false;
  btnInvert.onclick = () => {
    drawParams.showInvert = btnInvert.checked;
  };

  const btnEmboss = document.querySelector("#cb-emboss");
  btnEmboss.checked = false;
  btnEmboss.onclick = () => {
    drawParams.showEmboss = btnEmboss.checked;
  };

  loadJson();
} // end setupUI


const init = () => {
  audio.setupWebaudio(DEFAULTS.sound1);
	console.log("init called");
	console.log(`Testing utils.getRandomColor() import: ${utils.getRandomColor()}`);
	let canvasElement = document.querySelector("canvas"); // hookup <canvas> element
	setupUI(canvasElement);

  canvas.setupCanvas(canvasElement,audio.analyserNode);
  loop();
}



export {init};